package programming;
import static org.junit.Assert.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import org.junit.Test;

public class UniversityTest {
	private static HashMap<StudentId, String> studentMap = new HashMap<StudentId, String>();
	@Test
	public void test() throws IOException, Exception {
		StudentId st = new StudentId();
	
		Student S1 = new Undergraduate ("Matthew Jones", st.getInstance(), "Undergraduate", 120,"Computer Science","G400",LocalDate.of(1998, Month.JUNE, 13));
		University.registerStudent(S1);
		SmartCard Smart = new SmartCard(S1);
		Smart.getInstance();
	        studentMap.put(S1.studentId(), S1.name() + "-" + S1.studentId() + "-" + S1.studys() + "-" + S1.credits() + "-" + S1.courseTitle() + "-" + S1.courseNum() + "-" + S1.dob()+ "-" + Smart.getSmartCard());
		assertEquals("Test for the method of registerStudent",studentMap ,University.getStudentMap());
		Student S2 = new PostGraduateT ("Alvin Ho", st.getInstance(), "PostgraduateT", 180, "Computer Science","G420",LocalDate.of(1996, Month.JULY, 10));
		University.registerStudent(S2);
		SmartCard Smart2 = new SmartCard(S2);
		Smart2.getInstance();
	        studentMap.put(S2.studentId(), S2.name() + "-" + S2.studentId() + "-" + S2.studys() + "-" + S2.credits() + "-" + S2.courseTitle() + "-" + S2.courseNum() + "-" + S2.dob()+ "-" + Smart2.getSmartCard());
	    assertEquals("Test for the method of registerStudent",studentMap ,University.getStudentMap());
	
		assertEquals("Test for the method of noOfStudents",1 ,University.noOfStudents(S1.studys()));
		assertEquals("Test for the method of noOfStudents",1 ,University.noOfStudents(S2.studys()));
		University.terminateStudent(S1.studentId());
		studentMap.remove(S1.studentId());
		Student S3 = new PostGraduateT ("Chris Walker", S2.studentId(), "PostgraduateT", 180, "Computer Science","G420",LocalDate.of(1996, Month.JULY, 10));
		assertEquals("Test for the method of terminateStudent",studentMap ,University.getStudentMap());
		studentMap.replace(S2.studentId(), S2.name() + "-" + S2.studentId() + "-" + S2.studys() + "-" + S2.credits() + "-" + S2.courseTitle() + "-" + S2.courseNum() + "-" + S2.dob()+ "-" + Smart2.getSmartCard() , "Chris Walker" + "-" + S2.studentId()+ "-" + "PostgraduateT"+ "-" + 180+ "-" + "Computer Science"+ "-" +"G420"+ "-" +LocalDate.of(1996, Month.JULY, 10));
		University.amendStudentData(S2.studentId(), S3);
		 assertEquals("Test for the method of amendStudent",studentMap ,University.getStudentMap());
		
	
	}
	
	
	

}
