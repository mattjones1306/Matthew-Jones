package programming;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDate;


public class PostGraduateR extends Student {

	private String supervisor;
private int passMark = 90;

	public PostGraduateR(String name, StudentId studentId, String studys, int credits, String courseTitle,
			String courseNum, LocalDate dob) throws exception, FileNotFoundException, ParseException {
		super(name, studentId, studys, credits,  courseTitle, courseNum, dob);
this.supervisor = supervisor();
	}

	public String getsupervisor() {
		return supervisor;

	}




}
