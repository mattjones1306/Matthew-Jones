package programming;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDate;

public class Undergraduate extends Student {

	private int passMark = 40;

	public Undergraduate(String name, StudentId studentId, String studys, int credits, String courseTitle,
			String courseNum, LocalDate dob) throws exception, FileNotFoundException, ParseException {
		super(name, studentId, studys, credits, courseTitle, courseNum, dob);
	}

}