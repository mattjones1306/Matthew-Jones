package programming;

class exception extends Exception {

	
	private static final long serialVersionUID = 1L;
	
	public exception(String s){
		super(s);
	}
	public exception(){
		
	}
}
