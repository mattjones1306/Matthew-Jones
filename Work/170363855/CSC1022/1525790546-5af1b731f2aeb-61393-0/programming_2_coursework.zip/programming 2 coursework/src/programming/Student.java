package programming;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDate;

import java.time.Period;

public abstract class Student implements Interface {
	private String name; // This is the variable which will hold the name of the person being added to the system.
	//this will change when a new student is added
	private StudentId studentId; // This is the variable which holds the student ID. This will change when a new student is added.
	private String studentIdString;// This is the variable which holds the Student Id in string formThis will change when a new student is added.
	private String studys;// This is the variable which holds the type of student. This will change when a new student is added.
	private LocalDate dob;// This is the variable which holds the date of birth. This will change when a new student is added.
	private int credits;// This is the variable which holds the credits which are needed for the course. This will change when a new student is added.
	private String courseTitle;// This is the variable which holds the course title. This will change when a new student is added.
	private String courseNum;// This is the variable which holds the course number. This will change when a new student is added.
	private String supervisor;// This is the variable which holds the supervisor for a Postgraduate research student. This will change when a new student is added.
	private int age;// This is the variable which holds the age of the student after being calculated. This will change when a new student is added.
	private LocalDate currentDate;// This is the variable which holds the current date.


	public Student(String name, StudentId studentId, String studys, int credits, String courseTitle, String courseNum,
			LocalDate dob) throws exception, FileNotFoundException, ParseException {

		this.studentId = studentId;

		LocalDate day = LocalDate.now();//This makes and instance of the date which will be used to calculate age.
		this.currentDate = day; //This sets the variable as the date.
		this.age = calculateAge(dob, currentDate);//This sets the variable as the return of my calculate age method.
		this.studentIdString = studentId + "";//This sets the variable as the student Id but as a string.
		this.name = name; //This sets the variable as the name from the student being passed in.
		this.studys = studys;//This sets the variable as the name from the student being passed in.
		this.dob = dob;//This sets the variable as the date of birth from the student being passed in.
		this.credits = credits;//This sets the variable as the credits from the student being passed in.
		this.courseTitle = courseTitle;//This sets the variable as the course title from the student being passed in.
		this.courseNum = courseNum;//This sets the variable as the course number from the student being passed in.
		Supervisor sp = new Supervisor();// This makes an instance of the supervisor class
		this.supervisor = sp.readFromSupervisor();// This sets the variable as the return from my supervisors method.

	}








	public static int calculateAge(LocalDate dob, LocalDate currentDate) {
		if ((dob != null) && (currentDate != null)) {// This part means that if either date of birth or current date are not empty to carry out the return otherwise return 0.
			return Period.between(dob, currentDate).getYears();// This is how I calculate the age for the variable.

		} else {
			return 0;
		}
	}

	public String name() {//This is the get method for name so I can access this easily.
		return name;
	}

	public StudentId studentId() {//This is the get method for student Id so I can access this easily.
		return studentId;
	}

	public String studys() {//This is the get method for the type of study so I can access this easily.
		return studys;
	}

	public LocalDate dob() {//This is the get method for date of birth so I can access this easily.
		return dob;
	}

	public int credits() {//This is the get method for credits so I can access this easily.
		return credits;
	}

	public String courseTitle() {//This is the get method for course title so I can access this easily.
		return courseTitle;
	}

	public String courseNum() {//This is the get method for course number so I can access this easily.
		return courseNum;
	}

	public String supervisor() {//This is the get method for supervisor so I can access this easily.
		return supervisor;
	}

	public int getAge() {//This is the get method for age so I can access this easily.
		return age;
	}
	public String getStudentIdString() {//This is the get method for the string student Id so I can access this easily.
		return studentIdString;
	}
	


}
