package programming;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import org.junit.Test;

public class StudentTest {

	@Test
	public void test() throws IOException, Exception{
	

	StudentId st = new StudentId();
	    
	  
	
		Student S1 = new Undergraduate ("Matthew Jones", st.getInstance(), "Undergraduate", 120,"Computer Science","G400",LocalDate.of(1998, Month.JUNE, 13));
		University.registerStudent(S1);
		
		
		assertEquals("Test for the get method of name", "Matthew Jones", S1.name());
		assertEquals("Test for the get method of Id", "a1001", S1.getStudentIdString()); 
		assertEquals("Test for the get method of studys", "Undergraduate", S1.studys());
		assertEquals("Test for the get method of credits", 120, S1.credits()); 
		assertEquals("Test for the get method of course name", "Computer Science", S1.courseTitle());
		assertEquals("Test for the get method of course number", "G400", S1.courseNum()); 
		assertEquals("Test for the get method of date of birth",LocalDate.of(1998, Month.JUNE, 13), S1.dob());
		assertEquals("Test for the get method of age", 19, S1.getAge());
		
		

		Student S2 = new PostGraduateT ("Alvin Ho", st.getInstance(), "PostgraduateT", 180, "Computer Science","G420",LocalDate.of(1996, Month.JULY, 10));
		University.registerStudent(S2);
		
		assertEquals("Test for the get method of name", "Alvin Ho", S2.name());
		assertEquals("Test for the get method of Id", "a1002", S2.getStudentIdString()); 
		assertEquals("Test for the get method of studys", "PostgraduateT", S2.studys());
		assertEquals("Test for the get method of credits", 180, S2.credits()); 
		assertEquals("Test for the get method of course name", "Computer Science", S2.courseTitle());
		assertEquals("Test for the get method of course number", "G420", S2.courseNum()); 
		assertEquals("Test for the get method of date of birth",LocalDate.of(1996, Month.JULY, 10), S2.dob());
		assertEquals("Test for the get method of name", 21, S2.getAge());
		assertEquals("Test for the get method to get a supervisor", true , (S2.supervisor()!=null));

	}

}
