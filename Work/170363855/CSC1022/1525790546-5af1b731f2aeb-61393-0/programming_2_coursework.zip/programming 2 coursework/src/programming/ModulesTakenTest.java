package programming;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.junit.Test;

import junit.framework.TestCase;

public class ModulesTakenTest extends TestCase {
	
	
	
	
	private static Scanner s;
	private static Scanner lineS;
	private int creditsP = 0;
	private int creditsU = 0;
	
	private static HashMap<String, String> modulesU = new HashMap<String, String>();
	private static HashMap<String, String> modulesP = new HashMap<String, String>();
	List<String> listModules = new ArrayList<String>();

	//String undergraduate = "H:/workspace/programming 2 coursework/src/modules.txt";
	String undergraduate = "file/modules.txt";
	String postgraduate = "file/Pmodules.txt";

		@Test
		public void test() throws IOException, Exception {

		try {
			s = new Scanner(new File(undergraduate));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		while (s.hasNextLine()) {
			String line = s.nextLine();
			lineS = new Scanner(line);
			lineS.useDelimiter(",");
			while (lineS.hasNext()) {
				String mCode = lineS.next();
				modulesU.put("Code", mCode);
				String mCourse = lineS.next();
				modulesU.put("Course", mCourse);
				String mCredits = lineS.next();
				creditsU = (creditsU + Integer.parseInt(mCredits.substring(1, 3)));
				listModules.add(line);
				modulesU.put("Credits", mCredits);

				
			

		}
			
		}
			
		
	

		try {
			s = new Scanner(new File(postgraduate));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while (s.hasNextLine()) {
			String line = s.nextLine();

			lineS = new Scanner(line);
			lineS.useDelimiter(",");
			while (lineS.hasNext()) {
				String mCode = lineS.next();
				modulesP.put("Code", mCode);
				String mCourse = lineS.next();
				modulesP.put("Course", mCourse);
				String mCredits = lineS.next();
				creditsP = (creditsP + Integer.parseInt(mCredits.substring(1, 3)));
				listModules.add(line);
				modulesP.put("Credits", mCredits);

			}

		
		
		}
		ModulesTaken m = new ModulesTaken();
		m.readFromFileU();
		m.readFromFileP();
		assertEquals("Test for the undergraduate credits", creditsU, m.getCreditsU());
		assertEquals("Test for the postgraduate credits", creditsP, m.getCreditsP());
		assertEquals("Test for the undergraduate modules",listModules , m.listModules);
		
		
		}

}