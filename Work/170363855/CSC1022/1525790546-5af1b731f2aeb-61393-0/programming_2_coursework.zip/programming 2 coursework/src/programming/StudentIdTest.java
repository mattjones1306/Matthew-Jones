package programming;

import static org.junit.Assert.assertEquals;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import junit.framework.TestCase;

public class StudentIdTest extends TestCase {

	public void test() throws IOException, Exception{
	StudentId st = new StudentId();
	Student S1 = new Undergraduate ("Matthew Jones", st.getInstance(), "Undergraduate", 120,"Computer Science","G400",LocalDate.of(1998, Month.JUNE, 13));
	University.registerStudent(S1);
	
	
	assertEquals("Test for the get method for Id", "a1001", st.getId());

	Student S2 = new PostGraduateT ("Alvin Ho", st.getInstance(), "PostgraduateT", 180, "Computer Science","G420",LocalDate.of(1996, Month.JULY, 10));
	University.registerStudent(S2);
	
	assertEquals("Test for the get method for Id", "a1002", st.getId());
	}

}
