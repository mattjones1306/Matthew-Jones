package programming;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;



public class Supervisor {
	private String supervisor;// This is the variable which holds the
	
	
	public Supervisor() throws FileNotFoundException{
		this.supervisor = readFromSupervisor();
	}
	
	public String getSupervisor() {//This is the get method for name so I can access this easily.
		return supervisor;
	}



	public String readFromSupervisor() throws FileNotFoundException{
		Scanner s = new Scanner(new File("file/supervisors.txt"));// This reads the file and puts the supervisors from the text file into a list.
		ArrayList<String> list = new ArrayList<String>();
		while (s.hasNext()){
		    list.add(s.next());
		}
		s.close();
		
		return (list.get((new Random()).nextInt(list.size())));// This returns a random supervisor from the list.
	}
}
