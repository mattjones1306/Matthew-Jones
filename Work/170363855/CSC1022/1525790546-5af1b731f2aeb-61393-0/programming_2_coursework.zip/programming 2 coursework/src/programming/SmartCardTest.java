package programming;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Month;

import org.junit.Test;

public class SmartCardTest {

	@Test
	public void test() throws IOException, Exception {
		StudentId st = new StudentId();
		Student S1 = new Undergraduate ("Matthew Jones", st.getInstance(), "Undergraduate", 120,"Computer Science","G400",LocalDate.of(1998, Month.JUNE, 13));
		University.registerStudent(S1);
		
		SmartCard Smart = new SmartCard(S1);
		Smart.getInstance();
		assertEquals("Test for the get method of smartcard", "SmartCard:Matthew Jones|MJ-2018-10|1998-06-13|08/05/18", Smart.getSmartCard());
		assertEquals("Test for the get method of name", "Matthew Jones", Smart.getName());
		assertEquals("Test for the get method of Id", "a1001", Smart.getStudentId()); 
		assertEquals("Test for the get method of date of birth",LocalDate.of(1998, Month.JUNE, 13) , Smart.getDob());
		assertEquals("Test for the get method of age", 19, Smart.getAge());
		
		
		Student S2 = new PostGraduateT ("Alvin Ho", st.getInstance(), "PostgraduateT", 180, "Computer Science","G420",LocalDate.of(1998, Month.JULY, 10));
		University.registerStudent(S2);
		SmartCard Smart2 = new SmartCard(S2);
	
		
		 try {
			 Smart2.getInstance();
		        fail();
		    } 
		    catch (exception e) {
		        final String expected ="You have to be 20 or over to get a postgraduate smartcard.";
		        assertEquals( expected, e.getMessage());
		    }        
		}
		
	}


