package programming;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

public class SmartCard {

	private String name;// This is the variable which holds the name.
	private String[] splitname;// This is the variable which holds the splitname.
	private String firstN;// This is the variable which holds the first name.
	private String lastN;// This is the variable which holds the last name.
	private LocalDate dob;// This is the variable which holds the date of birth.
	public StudentId studentId;// This is the variable which holds the student Id.
	private LocalDate dateOfIssue;// This is the variable which holds the date of issue.
	private String studys;// This is the variable which holds the studys.
	private int age;// This is the variable which holds the age.
	private static int twoNumbers = 10;// This is the variable which holds the serial numbers.
	private String smartCard;// This is the variable which holds the smart card.
	private String smartCardString;// This is the variable which holds the string smart card.
	private static HashMap<String, SmartCard> map2 = new HashMap<String, SmartCard>();
	private static HashMap<String, String> initalsMap = new HashMap<String, String>();

	public SmartCard(Interface S) throws exception {
		this.name = S.name();
		this.dob = S.dob();
		this.studentId = S.studentId();// This pulls the information out of the student class for fields needed in the smart card.

		this.studys = S.studys();
		this.age = S.getAge();

	}

	public SmartCard(String smartCard) {
		this.smartCardString = smartCardString;

	}

	public LocalDate getDob() {
		return dob;
	}

	public String getStudentId() {
		return studentId+"";
	}

	public LocalDate getDateOfIssue() {
		return dateOfIssue;
	}

	public int getAge() {
		return age;
	}


	public String getName() {
		return name;
	}

	public String getSmartCard() {
		return smartCardString;
	}

//	public static HashMap<String, SmartCard> getMap2(StudentId studentId) {
//		return map2;
//	}

	public final SmartCard getInstance() throws exception, ParseException {

		splitname = name.split(" ");
		firstN = splitname[0];
		lastN = splitname[1];
		StringBuilder sb = new StringBuilder();
		sb.append(firstN.charAt(0));
		sb.append(lastN.charAt(0));
		String initials = sb.toString();// This makes the initials for the smart card.
		
		
		Date date = new Date();

		int year = LocalDate.parse(new SimpleDateFormat("yyyy-MM-dd").format(date)).getYear();// This creates the year.
	

		DateFormat df1 = DateFormat.getDateInstance(DateFormat.SHORT);
		String s1 = df1.format(date);// This creates the date
		String smartCardNumber = initials + "-" + year + "-" + twoNumbers;// This joins all of the earuiler infomation together.
		smartCard = "SmartCard:" + name + "|" + smartCardNumber+ "|" + dob+ "|" + s1;		String Id = String.valueOf(studentId);
		smartCardString = smartCard;
		
		if (studys.equals("Undergraduate") && age < 17) {
			throw new exception("You have to be 17 or over to get a undergraduate smartcard.");
		}
		if (!studys.equals("Undergraduate") && age < 20)
			throw new exception("You have to be 20 or over to get a postgraduate smartcard.");

		if (!initalsMap.containsKey(initials)) {
			map2.put(Id, new SmartCard(smartCard));// This puts the smart card on the map if there are no same initials.
			initalsMap.put(initials, initials);
		} else {
			twoNumbers++; // I there are the same initials it increment the number so the serial number is different.

			smartCard = initials + "-" + year + "-" + twoNumbers;
			map2.put(Id, new SmartCard(smartCard));
		}


	
		return map2.get(smartCard);
	
	

	}

	public String toString() {
		
		return smartCard;

	}

}