package programming;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class ModulesTaken {
	private static Scanner s;// This is the variable which holds the
	private static Scanner lineS;// This is the variable which holds the
	private int creditsP = 0;// This is the variable which holds the
	private int creditsU = 0;// This is the variable which holds the

	private static HashMap<String, String> modulesU = new HashMap<String, String>();
	private static HashMap<String, String> modulesP = new HashMap<String, String>();
	List<String> listModules = new ArrayList<String>();

	//String undergraduate = "H:/workspace/programming 2 coursework/src/modules.txt";
	String undergraduate = "file/modules.txt";// These are the text files with the modules in.
	String postgraduate = "file/Pmodules.txt";
	String line = null;

	public List<String> readFromFileU() throws Exception, IOException {
		s = new Scanner(new File(undergraduate));
		while (s.hasNextLine()) {
			String line = s.nextLine();
			lineS = new Scanner(line);
			lineS.useDelimiter(",");
			while (lineS.hasNext()) {
				String mCode = lineS.next();
				modulesU.put("Code", mCode);
				String mCourse = lineS.next();
				modulesU.put("Course", mCourse);
				String mCredits = lineS.next();
				creditsU = (creditsU + Integer.parseInt(mCredits.substring(1, 3)));
				listModules.add(line);
				modulesU.put("Credits", mCredits);

			}

		}
		if (getCreditsU() < 120) {
			throw new exception("You do not have enought credits for your course");
		} else {
			
			return listModules;
			
		}
	}

	public List<String> readFromFileP() throws Exception, IOException {
		s = new Scanner(new File(postgraduate));
		while (s.hasNextLine()) {
			String line = s.nextLine();

			lineS = new Scanner(line);
			lineS.useDelimiter(",");
			while (lineS.hasNext()) {
				String mCode = lineS.next();
				modulesP.put("Code", mCode);
				String mCourse = lineS.next();
				modulesP.put("Course", mCourse);
				String mCredits = lineS.next();
				creditsP = (creditsP + Integer.parseInt(mCredits.substring(1, 3)));
				listModules.add(line);
				modulesP.put("Credits", mCredits);

			}

			
		}

		if (creditsP < 180) {
			throw new exception("You do not have enought credits for your course");
		} else {
			return listModules;
		}

	
	}

	public int getCreditsU() {//This is the get method for name so I can access this easily.
		return creditsU;
	}

	public int getCreditsP() {//This is the get method for name so I can access this easily.
		return creditsP;
	}



}
