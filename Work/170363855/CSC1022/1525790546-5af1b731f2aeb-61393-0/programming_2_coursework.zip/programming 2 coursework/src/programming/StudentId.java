package programming;

import java.util.HashMap;
import java.util.Random;

public class StudentId {
	private char letter = 'a';// This is the variable which holds the letter for my student Id.
	private int number2 = 1000;// This is the variable which holds the number for my Student Id.
	private String Id;// This is the variable which holds the string student Id.
	private StudentId I;// This is the variable which holds the object Id.
	private static HashMap<StudentId, StudentId> map = new HashMap<StudentId, StudentId>();

	public StudentId(String Id) {
		this.Id = Id;
	}

	public StudentId() {

	}

	public final StudentId getInstance() throws exception {

		number2++;

		if (number2 == 9999) {
			letter++;
			if (letter > 'z') {
				throw new exception("no more Id g");// This increments the number and the letter until there are no more ids.
			}
		}

		StringBuilder sb = new StringBuilder();
		sb.append(letter);
		sb.append(number2);
		Id = sb.toString(); // This uses the two variable to build the string to be used in the object factory

		I = new StudentId(Id);

		if (!map.containsKey(I)) {
			map.put(I, I); // This puts the Id in a map.

		} else {

			getInstance();// if the student Id is the same it will replay the method and the increment will change it.

		}

		return I;

	}

	public String getId() {//This is the get method for name so I can access this easily.
		return Id;
	}

	public String toString() {
		return Id;
	}
}