package programming;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.List;


public class University {

	private static StudentId ID;// This is the variable which holds the Id. 
	private static String typeS;// This is the variable which holds the type of student being passed through.
	private static int underGraduateCount = 0;// This is the variable which holds the count for the number of undergraduate students.
	private static int postGraduateRCount = 0;// This is the variable which holds the count for the number of postgraduate research students.
	private static int postGraduateTCount = 0;// This is the variable which holds the count for the number of postgraduate taught students.
	private static HashMap<StudentId, String> studentMap = new HashMap<StudentId, String>();// This is the map which holds the student records. Here I can change add and remove students from the system.
	private static HashMap<StudentId,List< String>> moduleMap = new HashMap<StudentId,List <String>>();//This is the map which holds the modules that a student is taking.

	public static void main(String[] args) throws IOException, Exception {


		StudentId std = new StudentId();//I create an instance of the student Id class.
		ID = std.getInstance();// The variable Id is now  the return of my get instance student Id class.
		Interface S1 = new Undergraduate("Matthew Jones", ID, "Undergraduate", 120, "Computer Science", "G400",// This is the first student that I add in.
				LocalDate.of(1998, Month.JUNE, 13));
		registerStudent(S1);// I then run the student through the registerStudent method.

		Interface S2 = new Undergraduate("Matty Jennings", std.getInstance(), "Undergraduate", 120,// This is the second student that I add in.
				"Computer Science", "G400", LocalDate.of(1998, Month.JUNE, 9));
		registerStudent(S2);// I then run the student through the registerStudent method.
		Interface S3 = new PostGraduateR("Alvin Ho", std.getInstance(), "PostgraduateT", 180,  "Computer Science",// This is the third student that I add in.
				"G400", LocalDate.of(1996, Month.JUNE, 9));
		registerStudent(S3);// I then run the student through the registerStudent method.
		 amendStudentData(ID, S2);// I the run the amendStudent method which changes S1's records with S2's. 
		noOfStudents(typeS);//I then run my noOfStudents method which will store how many of a particular students are enrolled.
	;
		
		 terminateStudent(ID);//I then run my terminateStudent method which will remove S2 from the records.
	}
	

	public static void registerStudent(Interface S) throws IOException, Exception {

		typeS = S.studys(); // I make the variable the same as the type of student being passed through.
		ModulesTaken m = new ModulesTaken();
		if (S.studys() == "Undergraduate") {//This then differs what type of student they are so I can make my count. I then put Put the student in the map then increase the count variable.
			studentMap.put(S.studentId(), S.name() + "-" + S.studentId() + "-" + S.studys() + "-" + S.credits() + "-" + S.courseTitle() + "-" + S.courseNum() + "-" + S.dob());
			underGraduateCount++;
			if (S.getAge() > 16)// This then checks the age of the student to see if they can get a smart card.
				issueSmartCard(S);//This then runs the issue smart card method passing through the students records.
			moduleMap.put(S.studentId(),m.readFromFileU());
			
		}
		if (S.studys() == "PostgraduateT") {//This then differs what type of student they are so I can make my count. I then put the student in the map then increase the count variable.
			studentMap.put(S.studentId(), S.name() + "-" + S.studentId() + "-" + S.studys() + "-" + S.credits() + "-" + S.courseTitle() + "-" + S.courseNum() + "-" + S.dob());
			postGraduateTCount++;
			if (S.getAge() > 19){// This then checks the age of the student to see if they can get a smart card.
				issueSmartCard(S);//This then runs the issue smart card method passing through the students records.
				}
			moduleMap.put(S.studentId(), m.readFromFileP()); 
		
			
		}

		if (S.studys() == "PostgraduateR") {//This then differs what type of student they are so I can make my count. I then put the student in the map then increase the count variable.
			studentMap.put(S.studentId(), S.name() + "-" + S.studentId() + "-" + S.studys() + "-" + S.credits()  + "-" + S.courseTitle() + "-" + S.courseNum() + "-" + S.dob() + "-" + S.supervisor());
			postGraduateRCount++;
			if (S.getAge() > 19)// This then checks the age of the student to see if they can get a smart card.
				issueSmartCard(S);//This then runs the issue smart card method passing through the students records.
		}


	}

	public static void issueSmartCard(Interface S) throws exception, ParseException {
		SmartCard Smart = new SmartCard(S);
		Smart.getInstance();// This runs the get instance method for smart card.
		ID = S.studentId();
		studentMap.remove(S.studentId());//This removes the student records without the smart card.
		if (S.studys() != "PostgraduateR") {// I make this if statements to allow the supervisor variable to stay with the right students.
			studentMap.put(S.studentId(),// I then put the student back in the map with the smart card included.
					S.name() + "-" + S.studentId() + "-" + S.studys() + "-" + S.credits() + "-"
							+ S.courseTitle() + "-" + S.courseNum() + "-" + S.dob() + "-" + Smart.getSmartCard());
		} else {
			studentMap.put(S.studentId(),
					S.name() + "-" + S.studentId() + "-" + S.studys() + "-" + S.credits() + "-"
							+ S.courseTitle() + "-" + S.courseNum() + "-" + S.dob() + "-" + S.supervisor() + "-"
							+ Smart.getSmartCard());
		}
	}

	public static int noOfStudents(String typeS) {

		
		if (typeS == "Undergraduate") {// I get the type that wants to be used here by using the typeS variable.
			return (underGraduateCount);//This returns the count
		}
		if (typeS == "PostgraduateT") {// I get the type that wants to be used here by using the typeS variable.
			return (postGraduateTCount);//This returns the count
		}

		if (typeS == "PostgraduateR") {// I get the type that wants to be used here by using the typeS variable.
			return (postGraduateRCount);//This returns the count
		} else
			return 0;//This returns nothing as they must have made an error if it was not above.

	}

	public static HashMap<StudentId, String> getStudentMap() {//This returns the student map to be used.
		return studentMap;
	}


	public static void amendStudentData(StudentId ID, Interface S) {

		studentMap.replace(ID, studentMap.get(ID), S.name() + "-" + S.studentId() + "-" + S.studys() + "-" + S.credits()// This changes the student records by replacing the student in a map with another set of fields for easy use.
				 + "-" + S.courseTitle() + "-" + S.courseNum() + "-" + S.dob());
	
	}

	public static void terminateStudent(StudentId ID) {
		
		studentMap.remove(ID);// This removes a student from the map and erases their records
		

	}

}
