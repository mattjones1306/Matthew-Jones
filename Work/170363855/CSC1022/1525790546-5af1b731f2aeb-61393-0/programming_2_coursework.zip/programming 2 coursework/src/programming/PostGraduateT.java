package programming;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDate;

public class PostGraduateT extends Student {

	private int passMark = 90;
	
	public PostGraduateT(String name, StudentId studentId, String studys, int credits, String courseTitle,
			String courseNum, LocalDate dob) throws exception, FileNotFoundException, ParseException {
		super(name, studentId, studys, credits,courseTitle, courseNum, dob);

	}
}
