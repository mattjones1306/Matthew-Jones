package programming;

import java.time.LocalDate;

public interface Interface {
	
	String name();// The interface holds the methods which will be used throughout the student.
	 StudentId studentId();
	 String studys();
	 LocalDate dob();
	 int credits();
	 String courseTitle();
	 String courseNum();
	int getAge();
	String supervisor();
	
	
	
}
