package programming;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;

public class SupervisorTest {

	@Test
	public void test() throws FileNotFoundException {
		
		
		Supervisor s = new Supervisor();
		
		
		assertEquals("Test for the get method to make supervisor", true , (s.readFromSupervisor()!=null));
		assertEquals("Test for the get method to get a supervisor", true , (s.getSupervisor()!=null));
	}

}
