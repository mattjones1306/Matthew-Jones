package main.java;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Class to represent a Word i.e. a sequence of letters
 * 
 * @author Jennifer Warrender
 */
public class Word {

	// constant(s)
	// public static final char[] LETTERS =
	// "abcdefghijklnnopqrstuvwyxz".toCharArray();
	public static final char[] LETTERS = "abcdefghijklmnopqrstuvwxyz".toCharArray();
	// private static final int[] SCORES = { 1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1,
	// 1, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4,
	// 10 };
	private static final int[] SCORES = { 1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4,
			10 };
	private static final Map<Character, Integer> TILES_MAP = scoreMap();

	// instance variables
	private char[] letters = new char[0];

	// constructor
	public Word(String word) {
		if (isValid(word)) {
			this.letters = word.toCharArray();
		}
	}

	// private method to populate scores map
	// makes a letter have a score and puts it on the map
	private static Map<Character, Integer> scoreMap() {
		Map<Character, Integer> tilesMap = new HashMap<Character, Integer>();
		// for (int i = 1; i < LETTERS.length; i++){
		for (int i = 0; i < LETTERS.length; i++) {
			tilesMap.put(LETTERS[i], SCORES[i]);
		}
		return tilesMap;
	}

	// private method to check whether a given word is valid
	private static boolean isValid(String word) {
		char[] letters = word.toLowerCase().toCharArray();
		for (char w : letters) {
			boolean found = false;
			for (char l : LETTERS) {
				if (w == l) {
					found = true;
					break;
				}
			}
			if (!found)
				return false;
		}
		return true;
	}

	// method that returns letters of word
	public char[] getLetters() {
		// return LETTERS;
		return letters;
	}

	// method that returns first letter of word
	public char getFirst() {
		return letters[0];
	}

	// method that determines if a sequence of letters is empty
	public boolean isEmpty() {
		if (letters.length > 0)
			return false;

		return true;
	}

	// method that determines if word starts with given characters
	public boolean startsWith(char[] prefix) {
		for (int i = 0; i < prefix.length; i++) {
			if (prefix[i] == letters[i])
				// return false;
				// }
				// return true;
				// }

				return true;
		}
		return false;
	}

	// method that calculates total score of word
	public int getScore() {
		int total = 0;
		for (char l : getLetters())
			total += TILES_MAP.get(l);
		return total;
	}

	// method that returns String representation of word
	public String toString() {
		return new String(letters);
	}

	// HINT: DO NOT CHANGE THIS!
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(letters);
		return result;
	}

	// YOU CAN'T TOUCH THIS (OH-OH OH OH OH-OH-OH)!!!
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Word other = (Word) obj;
		if (!Arrays.equals(letters, other.letters))
			return false;
		return true;
	}
}