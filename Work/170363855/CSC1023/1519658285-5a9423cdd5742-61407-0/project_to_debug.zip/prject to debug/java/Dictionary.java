package main.java;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * Class to store Dictionary information i.e. a mapping from letters to sets of
 * Words
 * 
 * @author Jennifer Warrender
 */
public class Dictionary {

	// constant(s)
	private static final String fileName = "dictionary.txt";

	// instance variables
	public Map<Character, Set<Word>> dictionary;

	// constructor
	public Dictionary() {
		dictionary = makeDictionary(readWordsFromFile());
	}

	// reads set of words from file
	private Set<Word> readWordsFromFile() {
		Set<Word> words = new HashSet<Word>();
		try {
			File file = new File("src/main/resources/" + fileName);
			Scanner sc = new Scanner(file);
			while (sc.hasNextLine()) {
				String word = sc.next();
				words.add(new Word(word));
			}
			sc.close();
		} catch (Exception e) {
			// FAIL QUIETLY!
			System.out.println("Error: Unable to read " + fileName);
		}
		return words;
	}

	// generates dictionary from a given set of words
	private Map<Character, Set<Word>> makeDictionary(Set<Word> words) {
		Map<Character, Set<Word>> dictionary = new HashMap<Character, Set<Word>>();
		for (Word word : words) {
			// only add if valid
			if (!word.isEmpty()) {
				char key = word.getFirst();
				Set<Word> values;
				if (dictionary.containsKey(key))
					values = dictionary.get(key);
				else
					values = new HashSet<Word>();
				values.add(word);
				dictionary.put(key, values);
			}
		}
		return dictionary;
	}

	// checks whether a given word is contained in the dictionary
	public boolean isValid(Word word) {
		if (!word.isEmpty()) {
			char key = word.getFirst();
			// if (dictionary.contains(key))
			if (dictionary.get(key).contains(word))
				return (dictionary.get(key).contains(word));
		}
		return false;
	}

	// finds all words that start with given character
	public Set<Word> startsWith(String prefix) {
		Set<Word> result = new HashSet<Word>();
		if (prefix.length() > 0) {
			char key = prefix.charAt(0);
			if (dictionary.containsKey(key)) {
				for (Word word : dictionary.get(key)) {
					if (word.startsWith(prefix.toCharArray())) {
						result.add(word);
					}
				}
			}
		}
		return result;
	}
}