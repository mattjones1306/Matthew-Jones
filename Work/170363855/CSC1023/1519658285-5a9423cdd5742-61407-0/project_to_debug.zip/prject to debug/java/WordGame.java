package main.java;

import java.util.HashMap;

/**
 * Class to store board information i.e. a mapping of coordinates to letters
 * 
 * @author Jennifer Warrender
 */
public class WordGame {

	// constant(s)
	public static final int MAX = 15;

	// instance variables
	private Dictionary dictionary;
	private HashMap<Position, Character> board;

	// constructor
	public WordGame(Dictionary dictionary) {
		this.dictionary = dictionary;
		// new empty board
		board = new HashMap<Position, Character>();
	}

	// check a word will fit in a given position
	public boolean roomForWord(Word w, Position p, boolean h) {
		char[] letters = w.getLetters();
		for (int i = 0; i < letters.length; i++) {
			Position key;
			if (p.getX() + i > 15 || p.getY() + i > 15)
				return false;
			if (h)
				key = new Position(p.getX() + i, p.getY());
			else
				// key = new Position(p.getX() + i, p.getY());
				key = new Position(p.getX(), p.getY() + i);
			if (board.containsKey(key))
				if (board.get(key) != letters[i])
					return false;
		}
		return true;
	}

	// places a valid word on the board
	public int placeWord(Word w, Position p, boolean h) {
		// if (roomForWord(w, p, h) || dictionary.isValid(w)) {
		if (roomForWord(w, p, h) && dictionary.isValid(w)) {
			char[] letters = w.getLetters();
			for (int i = 0; i < letters.length; i++) {
				Position key;
				if (h)
					key = new Position(p.getX() + i, p.getY());
				else
					key = new Position(p.getX(), p.getY() + i);
				board.put(key, letters[i]);
			}
			return w.getScore();
		}
		// return w.getScore();
		return 0;
	}

	// returns a string representation of the board
	public String toString() {
		String output = "";
		// for (int x = 1; x <= MAX; x++) {
		// for (int y = 1; y <= MAX; y++) {
		for (int y = 1; y <= MAX; y++) {
			for (int x = 1; x <= MAX; x++) {
				Position key = new Position(x, y);
				char tile = '_';
				if (board.containsKey(key)) {
					tile = board.get(key);
				}
				output += tile + " ";
			}
			output += "\n";
		}
		return output;
	}
}