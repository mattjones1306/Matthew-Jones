package main.java;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Set;

/**
 * Class to interact with user
 * 
 * @author Jennifer Warrender
 */
public class UserInterface {

	// constant(s)
	private static final String FILE_NAME = "statistics.txt";

	// instance variables
	private Scanner sc = new Scanner(System.in);
	private Dictionary dictionary = new Dictionary();
	private WordGame game;
	private int noOfGames = 0;
	private int maxScore = 0;
	private int currentScore = 0;

	// constructor
	public UserInterface() {
		readStatsFromFile();
	}

	// METHODS THAT INTERACT WITH USER
	// driver method
	public void run() {
		// welcome information
		System.out.println("Welcome to Scrabble-- v1.0");

		// start new game by default
		newBoard();

		// menu options
		int choice = 1;
		while (choice > 0) {
			printMenu();
			choice = getIntInput(0, 7);
			switch (choice) {
			case 0:
				// DO NOTHING!!!
				break;
			case 1:
				newBoard();
				break;
			case 2:
				printBoard();
				break;
			case 3:
				placeHorizontal();
				break;
			case 4:
				placeVertical();
				break;
			case 5:
				printValidWords();
				break;
			case 6:
				printPlayerStats();
				break;
			case 7:
				clearPlayerStats();
				break;
			default:
				// FAIL QUITELY!
				// System.out.println("Error: Unexpected choice");
				break;
			}
			// run();
		}

		// check/save stats
		newBoard();
		saveStatsToFile();

		// say goodbye world
		System.out.println("Goodbye!");
		sc.close();

		// exit
		System.exit(0);
	}

	// tell user of the menu options
	private void printMenu() {
		System.out.println();
		System.out.println("Please select from one of the following options: [0-7]");
		System.out.println("1 - New Board");
		System.out.println("2 - Print Board");
		System.out.println("3 - Place Horizontal Word");
		System.out.println("4 - Place Vertical Word");
		System.out.println("5 - Print Valid Words");
		System.out.println("6 - Print Player Statistics");
		System.out.println("7 - Clear Player Statistics");
		System.out.println("0 - Exit Game");
	}

	// get int value from user
	private int getIntInput(int min, int max) {
		int choice = -1;
		while (choice < min || choice > max) {
			System.out.print("> ");
			choice = sc.nextInt();
		}
		return choice;
	}

	// get word from user
	private String getStringInput() {
		System.out.println("Please enter a string value:");
		System.out.print("> ");
		String input = sc.next();
		return input;
	}

	// get position from user
	private Position getPosition() {
		System.out.println("Please enter the x value:");
		int x = getIntInput(1, WordGame.MAX);

		System.out.println("Please enter the y value:");
		int y = getIntInput(1, WordGame.MAX);
		return new Position(x, y);
	}

	// tell user the valid words (that have a given prefix)
	private void printValidWords() {
		String prefix = getStringInput();
		Set<Word> words = dictionary.startsWith(prefix);
		System.out.println(words);
	}

	// tell user their player stats
	private void printPlayerStats() {
		System.out.println("Max Score: " + maxScore);
		System.out.println("No of games played: " + noOfGames);
		System.out.println("Current Score: " + currentScore);
	}

	// METHODS THAT INTERACT WITH BOARD
	// create a new board
	private void newBoard() {
		if (maxScore < currentScore)
			maxScore = currentScore;
		if (currentScore > 0)
			noOfGames++;
		currentScore = 0;
		game = new WordGame(dictionary);
	}

	// print board to console
	private void printBoard() {
		System.out.println(game);
	}

	// place given word horizontally
	private void placeHorizontal() {
		Word w = new Word(getStringInput());
		Position p = getPosition();
		currentScore += game.placeWord(w, p, true);
	}

	// place given word vertically
	private void placeVertical() {
		Word w = new Word(getStringInput());
		Position p = getPosition();
		// currentScore += game.placeWord(w, p, true);
		currentScore += game.placeWord(w, p, false);
	}

	// METHODS THAT INTERACT WITH FILE
	// read statistics from file
	private void readStatsFromFile() {
		try {
			File file = new File("src/main/resources/" + FILE_NAME);
			Scanner sc = new Scanner(file);
			maxScore = sc.nextInt();
			noOfGames = sc.nextInt();
			sc.close();
		} catch (Exception e) {
			// FAIL QUIETLY!
			// System.out.println("Error: Unable to read " + FILE_NAME);
		}
	}

	// save statistics to file
	private void saveStatsToFile() {
		try {
			File file = new File("src/main/resources/" + FILE_NAME);
			PrintWriter out = new PrintWriter(new FileWriter(file));
			// out.println(noOfGa5mes);
			// out.println(maxScore);
			out.println(maxScore);
			out.println(noOfGames);
			out.close();
		} catch (Exception e) {
			// FAIL QUIETLY!
			// System.out.println("Error: Unable to read " + FILE_NAME);
		}
	}

	// OTHER 'LOGIC' METHODS
	// clear player stats
	private void clearPlayerStats() {
		noOfGames = 0;
		maxScore = 0;
		currentScore = 0;
	}

	// MAIN METHOD
	public static void main(String[] args) {
		UserInterface game = new UserInterface();
		game.run();
	}
}
