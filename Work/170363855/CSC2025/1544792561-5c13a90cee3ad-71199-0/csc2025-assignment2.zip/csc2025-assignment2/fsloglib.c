/*
 * Replace the following string of 0s with your student number
 * B7036385
 */
#include <lib.h>    // provides _syscall and message
#include <errno.h>
#include "fsloglib.h"

int startfslog(unsigned short ops2log) {
    if (!ops2log| (FSOP_NONE > ops2log) |(FSOP_ALL < ops2log)){
		errno = EINVAL;
		return -1;
	}
	
	message m;
	m.m1_i1 = ops2log;
	return _syscall(VFS_PROC_NR, STARTFSLOG,&m);
	
}

int stopfslog(unsigned short ops2stoplog) {
    if (!ops2stoplog| (FSOP_NONE > ops2stoplog) |(FSOP_ALL < ops2stoplog)){
		errno = EINVAL;
		return -1;
	}
	if (-1==ops2stoplog){
		errno = EINVAL;
		return -1;
	}
		message m;
	m.m1_i1 = ops2stoplog;
	return _syscall(VFS_PROC_NR, STOPFSLOG,&m);
}

int getfsloginf(struct fsloginf *fsloginf) {
    if(fsloginf == NULL)   {
    errno = EINVAL;
    return -1;
	}
		message m;
	m.m1_p1 = (char*)&fsloginf;
	return _syscall(VFS_PROC_NR, GETFSLOGINF,&m);
}

int getfslog(struct fsloginf *fsloginf, struct fslogrec fslog[]) {
       if(fsloginf == NULL|fslog ==NULL)   {
    errno = EINVAL;
    return -1;
	}
		message m;
	m.m1_p1 = (char*)&fsloginf;
	m.m1_p2 = (char*)&fslog;
	return _syscall(VFS_PROC_NR, GETFSLOG,&m);
}
