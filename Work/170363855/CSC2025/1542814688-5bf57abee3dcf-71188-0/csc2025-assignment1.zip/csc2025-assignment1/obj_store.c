/*
 * Replace the following string of 0s with your student number
 * 170363855
 */
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include "obj_store.h"

#define OSTR_REP_MAX 4096

static bool ostore_on = false;

const char *OFILE_FMT = "./%s/%#zx.txt";
const char *OSTORE_DIR = "ostore";

/* 
 * Declaration of private _get_ofile_path function.
 * 
 * Given an object id (e.g. the address of the object), this function returns
 * a newly allocated pathname for the object file. OFILE_FMT defines the path
 * format. 
 * For example, if the oid is 0x7f91c1402710, the returned path will be:
 *      ./ostore/0x7f91c1402710.txt
 *
 * _get_ofile_path dynamically allocates the path name. It is the user's
 * responsibility to free the allocated memory.
 *
 * _get_ofile_path is used by store_obj to create the filename to use to 
 * store an object and by unlink_obj to create the filename to unlink/delete.
 */
char *_get_ofile_path(size_t oid);

/* disable_ostore: implemented, do NOT change */
void disable_ostore() {
    ostore_on = false;
    
    DIR* osd = opendir(OSTORE_DIR);
    
    if (osd) {
        struct dirent* de;
        
        while ((de = readdir(osd))) {
            if (de->d_name[0] != '.') {
                char* path = NULL;
                (void) asprintf(&path, "./%s/%s", OSTORE_DIR, de->d_name);
                if (path) {
                    unlink(path);
                    free(path);
                }
            }
        }
        
        closedir(osd);
        
        rmdir(OSTORE_DIR);
    }
    
    errno = 0; // ignore errors
}

/* enable_ostore: implemented, do NOT change */
bool enable_ostore() {
    struct stat sbuf;
    
    errno = 0;
    
    int r = stat(OSTORE_DIR, &sbuf);
    
    if (r) {
        if (errno == ENOENT) {
            errno = 0;
            /* ostore doesn't exist, create it */
            r = mkdir(OSTORE_DIR, 0755);
        }
    } else if (!S_ISDIR(sbuf.st_mode)) {
        /* exists but is not a directory */
        r = -1;
        errno = ENOTDIR;
    }
    
    ostore_on = !r;
    
    return ostore_on;
}

/* ostore_is_on: implemented, do NOT change */
bool ostore_is_on() {
    return ostore_on;
}

/* 
 * TODO: IMPLEMENT store_obj
 * See comments to the store_obj function declaration in obj_store.h for the
 * specification of this function. Also see the comments below in the body of
 * the function.
 */
bool store_obj(void* obj, char* (*new_str_rep)(void*)) {
  	  
	  if (!obj||!new_str_rep) {
        errno = EINVAL;
        return false;
    }
	 else if (!ostore_on) {
        errno = ENOENT;
        return false;
    }
	char* object = ((*new_str_rep)(obj));
	if (strlen(object)> OSTR_REP_MAX){
    return false;
	}
	int file = open(_get_ofile_path((size_t)obj), O_WRONLY|O_CREAT|O_TRUNC);
	
	if(file<0){
		close(file);
		unlink(object);
		   errno = EINVAL;
        return false;
	}
	
	int file2 = write(file, object, strlen(object));
	
		if(file2<0){
		
		unlink(object);
		   errno = EINVAL;
        return false;
	}
		close(file);
	
	unlink(object);
	return true;
}


/* unlink_obj: implemented, do NOT change */
void unlink_obj(void *obj) {
    if (ostore_on && obj) {
        char *ofile_path = _get_ofile_path((size_t) obj);
    
        if (ofile_path) {
            unlink(ofile_path);
        
            free(ofile_path);
        }
    }
    
    return;
}

/* private _get_ofile_path: implemented do NOT change */
char *_get_ofile_path(size_t oid) {
    char *ofile_path = NULL;

    if (oid) 
        (void) asprintf(&ofile_path, OFILE_FMT, OSTORE_DIR, oid);
    
    return ofile_path;
}

